# Windows App Utility by Rockz - 12/3/19
# Remove/Reinstall default Windows apps

Write-Host " "
$oldtext = $host.ui.RawUI.ForegroundColor
$host.ui.RawUI.ForegroundColor = "Green"
Write-Host "      :::::::::   ::::::::   ::::::::  :::    ::: ::::::::: ";
Write-Host "     :+:    :+: :+:    :+: :+:    :+: :+:   :+:       :+:   ";
Write-Host "    +:+    +:+ +:+    +:+ +:+        +:+  +:+       +:+     ";
Write-Host "   +#++:++#:  +#+    +:+ +#+        +#++:++       +#+       ";
Write-Host "  +#+    +#+ +#+    +#+ +#+        +#+  +#+     +#+         ";
Write-Host " #+#    #+# #+#    #+# #+#    #+# #+#   #+#   #+#           ";
Write-Host "###    ###  ########   ########  ###    ### #########       ";
$host.ui.RawUI.ForegroundColor = $oldtext
Remove-Variable oldtext
Write-Host "                Windows App Utility";

Write-Host " "
Write-Host "Available options:"
Write-Host " "
Write-Host "1)"
Write-Host "Removes all Windows Store Apps except the following:"
Write-Host "Windows Store, Calculator, Sticky Notes, Windows Photos,"
Write-Host "Sound Recorder, Paint3D, Snip & Sketch, Xbox Applications,"
Write-Host "Video & Image Plugins, Movies & TV, Groove Music,"
Write-Host "Nvidia Control Panel, Intel Graphics Control Panel,"
Write-Host "Realtek Audio Console"
Write-Host " "
Write-Host "2)"
Write-Host "Reinstall all default Windows Store Apps"
Write-Host " "
Write-Host "To quit type 'q'"
Write-Host " "

write-host -nonewline "Please choose an option: "
 do { $key = $host.ui.rawui.readkey("NoEcho,IncludeKeyDown")}
    until ($key.Character -eq '1' -or $key.Character -eq '2' -or $key.Character -eq 'q')
if ($key.Character -eq 'q') { exit }
Write-Host $key.Character

if ($key.Character -eq '1') {
Write-Host "Removing Apps"
$SafeApps = "store|calculator|sticky|windows.photos|SoundRecorder|MSPaint|ScreenSketch|Xbox|VP9Video|WebMedia|WebpImage|HEIFImage|HEVCVideo|Zune|Nvidia|IntelGraphics|RealtekAudio|WavesMaxxAudio"
$progressPreference = 'silentlyContinue'
Write-Host "--Part 1"
Get-AppxPackage | where-object {$_.name -notmatch $SafeApps} | Remove-AppxPackage -erroraction silentlycontinue
Write-Host "--Part 2"
Get-AppxPackage | where-object {$_.name -notmatch $SafeApps} | Remove-AppxPackage -erroraction silentlycontinue
$progressPreference = 'Continue'
}

if ($key.Character -eq '2') {
Write-Host "Reinstalling Apps"
$progressPreference = 'silentlyContinue'
# We need to copy these acls later for when we cleanup
Out-File -FilePath $Env:ALLUSERSPROFILE\acl.txt -Force
Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -Command `"Get-AppxPackage -AllUsers | select InstallLocation | Format-Table -HideTableHeaders | Out-File -Width 1000 $Env:ALLUSERSPROFILE\applist.txt -Force; Get-Acl -Path $Env:ALLUSERSPROFILE\acl.txt | Set-Acl -Path $Env:ALLUSERSPROFILE\applist.txt`"" -Verb RunAs -Wait -WindowStyle Hidden
if ((Test-Path $Env:ALLUSERSPROFILE\applist.txt) -eq "True") {
    $AppList = Get-Content $Env:ALLUSERSPROFILE\applist.txt
    # Cleanup temp files
    Remove-Item $Env:ALLUSERSPROFILE\applist.txt
    Remove-Item $Env:ALLUSERSPROFILE\acl.txt
    $AppList = $AppList.Trim()
    foreach ($App in $AppList) {
            if ($App -ne "" ) {
                Add-AppxPackage -DisableDevelopmentMode -Register "$App\appxmanifest.xml" -ErrorAction SilentlyContinue
            }
        }
    }
if ((Test-Path $Env:ALLUSERSPROFILE\acl.txt) -eq "True") {
    Remove-Item $Env:ALLUSERSPROFILE\acl.txt
    }
$progressPreference = 'Continue'
}

Write-Host "All done, exiting..."
Sleep 3