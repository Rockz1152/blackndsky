# Windows App Utility by Rockz - 4-10-19
# Remove/Reinstall default Windows apps

# Verify Running as Admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
If (!( $isAdmin )) {
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs 
    exit
}

Write-Host " "
$t = $host.ui.RawUI.ForegroundColor
$host.ui.RawUI.ForegroundColor = "Green"
echo "      :::::::::   ::::::::   ::::::::  :::    ::: ::::::::: ";
echo "     :+:    :+: :+:    :+: :+:    :+: :+:   :+:       :+:   ";
echo "    +:+    +:+ +:+    +:+ +:+        +:+  +:+       +:+     ";
echo "   +#++:++#:  +#+    +:+ +#+        +#++:++       +#+       ";
echo "  +#+    +#+ +#+    +#+ +#+        +#+  +#+     +#+         ";
echo " #+#    #+# #+#    #+# #+#    #+# #+#   #+#   #+#           ";
echo "###    ###  ########   ########  ###    ### #########       ";
$host.ui.RawUI.ForegroundColor = $t
Remove-Variable t
echo "                Windows App Utility";

Write-Host " "
Write-Host "Available options:"
Write-Host " "
Write-Host "1)"
Write-Host "Removes all Windows Store Apps except the following:"
Write-Host "Windows Store, Calculator, Sticky Notes, Windows Photos,"
Write-Host "Sound Recorder, Paint3D, Snip & Sketch, Xbox Applications,"
Write-Host "Video & Image Plugins, Movies & TV, Groove Music"
Write-Host " "
Write-Host "2)"
Write-Host "Reinstall all default Windows Store Apps"
Write-Host " "
Write-Host "To quit type 'q'"
Write-Host " "

write-host -nonewline "Please choose an option: "
 do { $key = $host.ui.rawui.readkey("NoEcho,IncludeKeyDown")}
    until ($key.Character -eq '1' -or $key.Character -eq '2' -or $key.Character -eq 'q')
if ($key.Character -eq 'q') { exit }
Write-Host $key.Character

$SafeApps = "store|calculator|sticky|windows.photos|SoundRecorder|MSPaint|ScreenSketch|Xbox|VP9Video|WebMedia|WebpImage|HEIFImage|Zune"

if ($key.Character -eq '1') {
Write-Host "Removing Apps"
$progressPreference = 'silentlyContinue'
Write-Host "--Part 1"
Get-AppxPackage -AllUsers | where-object {$_.name -notmatch $SafeApps} | Remove-AppxPackage -erroraction silentlycontinue
Write-Host "--Part 2"
Get-AppxPackage -AllUsers | where-object {$_.name -notmatch $SafeApps} | Remove-AppxPackage -erroraction silentlycontinue
$progressPreference = 'Continue'
}

if ($key.Character -eq '2') {
Write-Host "Reinstalling Apps"
$progressPreference = 'silentlyContinue'
Get-AppxPackage -allusers | foreach {Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\appxmanifest.xml" -ErrorAction SilentlyContinue}
$progressPreference = 'Continue'
}

Write-Host "All done, exiting..."
Sleep 3